function changeColor(radioButton){
    var target = document.getElementById('td_text');
        target.style.color = radioButton.value;

}

var fontColorArray = ["gray","slategray","darkblue","teal","maroon","black"];
var bgColorArray = ["azure","linen","snow","powderblue","ivory","lightpink","lightyellow"];

var curFontColor=1;
var curBgColor=1;


function changeFontColor(){
    
}

function changeBgColor(){

}

function changeBg(selectElement){
    var target = document.getElementById('td_text');
    target.style.backgroundColor = selectElement.value;

    }
